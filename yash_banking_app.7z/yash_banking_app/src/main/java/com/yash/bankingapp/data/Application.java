package com.yash.bankingapp.data;

import java.util.Date;

import org.hibernate.Session;

import com.yash.bankingapp.domain.User;

public class Application {

	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		session.getTransaction().begin();
		
		User user = new User();
		
		user.setFirstName("Amit");
		user.setLastName("Jain");
		user.setbirthDate(new Date());
		user.setEmailAddress("pankaj@yash.com");
		user.setCreatedBy("pankaj");
		user.setCreatedDate(new Date());
		user.setLastUpdatedDate(new Date());
		user.setLastUpdatedBy("Amit");
		
		session.saveOrUpdate(user);
		session.getTransaction().commit();
		session.close();
		
		
	}
}
